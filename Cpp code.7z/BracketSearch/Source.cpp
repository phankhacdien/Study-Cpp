#include <iostream>
#include "BracketSearch.h"
using namespace std;

int main()
{
	BracketSearch run;
	run.Excute();
	return 0;
}